import dvdstore.project2dvdrental.Customer;
import dvdstore.project2dvdrental.VideoStoreController;
import org.junit.*;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.List;

public class CustomerTests{
    private static final String CUSTOMER_TEST_FILE = "customer_test.txt";

    VideoStoreController database;


    @After
    public void after() throws IOException {
        Files.delete(Paths.get(CUSTOMER_TEST_FILE));
    }

    @Test
    public void testAddCustomer() throws IOException {


    }

}
