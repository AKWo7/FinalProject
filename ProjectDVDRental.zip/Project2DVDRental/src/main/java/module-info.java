module dvdstore.project2dvdrental {
    requires javafx.controls;
    requires javafx.fxml;


    opens dvdstore.project2dvdrental to javafx.fxml;
    exports dvdstore.project2dvdrental;
}