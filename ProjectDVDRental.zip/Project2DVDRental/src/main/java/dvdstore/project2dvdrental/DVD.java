package dvdstore.project2dvdrental;

// Data model for a friend.
// The class captures first name, last name, phone number and birthday.
public class DVD {
    private  String movieName;
    private  String directorName;
    private  int idNum;
    private String availableYN;

    // Friend constructor
    public DVD (String movieName, String directorName, int idNum, String availableYN){
        this.movieName = movieName;
        this.directorName = directorName;
        this.idNum = idNum;
        this.availableYN = availableYN;

    }

    public String getMovieName(){
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getDirectorName(){
        return directorName;
    }

    public void setDirectorName(String directorName) {
        this.directorName = directorName;
    }

    public int getIdNum(){
        return idNum;
    }

    public void setIdNum(int idNum) {
        this.idNum = idNum;
    }


    public String getAvailableYN(){
        return availableYN;
    }

    public void setAvailableYN(String availableYN){
        this.availableYN = availableYN;
    }
}
