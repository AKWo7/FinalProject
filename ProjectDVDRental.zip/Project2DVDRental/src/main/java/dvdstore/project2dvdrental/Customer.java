package dvdstore.project2dvdrental;
import java.time.LocalDate;
// Data model for a friend.
// The class captures first name, last name, phone number and birthday.
public class Customer {

    private LocalDate returnDate;

    private  String firstName;
    private  String lastName;
    private  int idNumCust;
    private String rentedMovie;

    // Friend constructor
    public Customer (String firstName, String lastName, int idNumCust, String rentedMovie, LocalDate returnDate){
        this.firstName = firstName;
        this.lastName = lastName;
        this.idNumCust = idNumCust;
        this.rentedMovie = rentedMovie;
        this.returnDate = returnDate;

    }

    public String getFirstName(){
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName(){
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getIdNumCust(){
        return idNumCust;
    }

    public void setIdNumCust(int idNumCust) {
        this.idNumCust = idNumCust;
    }


    public String getRentedMovie(){
        return rentedMovie;
    }

    public void setRentedMovie(String rentedMovie){
        this.rentedMovie = rentedMovie;
    }

    public LocalDate getReturnDate(){
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

}
