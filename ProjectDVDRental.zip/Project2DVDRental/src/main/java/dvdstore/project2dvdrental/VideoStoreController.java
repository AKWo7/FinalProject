package dvdstore.project2dvdrental;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.List;


public class VideoStoreController {

    public DatePicker returnDatePicker;
    public Label lblMovieName;
    public Label lblMessage;
    public Label lblMessage1;
    public Label lblCopyNumber;

    public Label lblDirector;
    public Label lblFirstName;
    public Label lblLastName;
    public Label lblMovieRented;
    public Label lblRentedID;
    public Label lblReturnDate;
    public TableColumn AvailableColumn;
    public TableColumn MovieNameColumn;
    public TableColumn DirectorColumn;
    public TableColumn IDCopyColumn;
    public TableColumn ReturnDateColumn;
    public TableColumn FirstNameColumn;
    public TableColumn LastNameColumn;
    public TableColumn MovieRentedColumn;
    public TableColumn MovieCopyIDColumn;

    public ChoiceBox choiceboxAvailable;
    public Button btnDelete;
    public Button btnSubmit; //DVD
    public Button btnUpdate;
    public Button btnRegister; //Customer
    public Button btnRemove;
    private LocalDate now = LocalDate.now();
    @FXML
    private TextField fieldMovieName;
    @FXML
    private TextField fieldDirector;
    @FXML
    TextField fieldIDCopy;
    @FXML
    TextField fieldFirstName;
    @FXML
    TextField fieldLastName;
    @FXML
    TextField fieldMovieRented;
    @FXML
    TextField fieldCopyID;




    private String loadedFileDVD = "DVD_Catalogue.txt";
    private String loadedFileCustomer = "Customer_List.txt";

    @FXML
    ObservableList<String> AvailableList = FXCollections.observableArrayList("Yes","No"); //Choice box options

    @FXML
    TableView<DVD> DVDDisplay;
    public final ObservableList<DVD>  DVDsdata =
            FXCollections.observableArrayList();

    @FXML
    TableView<Customer> CustomerDisplay;
    public final ObservableList<Customer> CustomerData =
            FXCollections.observableArrayList();


    @FXML
    public void initialize() {
        choiceboxAvailable.setItems(AvailableList);
        initializeDVDTableView();
        initializeCustomerTableView();
        DVDDisplay.setEditable(true);
        MovieNameColumn.setEditable(true);
        IDCopyColumn.setEditable(true);
        DirectorColumn.setEditable(true);
        btnDelete.setDisable(true);
        CustomerDisplay.setEditable(true);
        FirstNameColumn.setEditable(true);
        LastNameColumn.setEditable(true);
        MovieCopyIDColumn.setEditable(true);
        ReturnDateColumn.setEditable(true);
        returnDatePicker.getEditor().setDisable(true);
        MovieRentedColumn.setEditable(true);
    }



    private void initializeDVDTableView()  {

        MovieNameColumn.setCellValueFactory(new PropertyValueFactory<DVD, String>("movieName"));
        DirectorColumn.setCellValueFactory(new PropertyValueFactory<DVD, String>("directorName"));
        IDCopyColumn.setCellValueFactory(new PropertyValueFactory<DVD, Integer>("idNum"));
        AvailableColumn.setCellValueFactory(new PropertyValueFactory<DVD, Integer>("availableYN"));


        loadDVD(loadedFileDVD);
    }

    private void initializeCustomerTableView()  {

        FirstNameColumn.setCellValueFactory(new PropertyValueFactory<Customer, String>("firstName"));
        LastNameColumn.setCellValueFactory(new PropertyValueFactory<Customer, String>("lastName"));
        MovieCopyIDColumn.setCellValueFactory(new PropertyValueFactory<Customer, Integer>("idNumCust"));
        MovieRentedColumn.setCellValueFactory(new PropertyValueFactory<Customer, String>("rentedMovie"));
        ReturnDateColumn.setCellValueFactory(new PropertyValueFactory<Customer, Integer>("returnDate"));

        loadCustomer(loadedFileCustomer);
    }

    public void deleteDVD(ActionEvent actionEvent) throws Exception {

        DVD selectedItem = DVDDisplay.getSelectionModel().getSelectedItem();
        DVDDisplay.getItems().remove(selectedItem);

        String movieName = selectedItem.getMovieName();
        String directorName = selectedItem.getDirectorName();
        String availableYN = selectedItem.getAvailableYN();

        removeFromDVD(movieName, directorName);

        selectDVD();
    }

    public void deleteCustomer(ActionEvent actionEvent) throws Exception {

        Customer selectedItem = CustomerDisplay.getSelectionModel().getSelectedItem();
        CustomerDisplay.getItems().remove(selectedItem);

        String firstName = selectedItem.getFirstName();
        String lastName = selectedItem.getLastName();
        String rentedMovie = selectedItem.getRentedMovie();

        removeFromCustomer(firstName, lastName);

        selectCustomer();
    }



    private void removeFromDVD(String movieName, String directorName) {
        removeFromDVDFile("DVD_Catalogue.txt", movieName, directorName);
    }

    private void removeFromCustomer(String firstName, String lastName) {
        removeFromCustomerFile("Customer_List.txt", firstName, lastName);
    }

    private void removeFromDVDFile(String fileName, String movieName, String directorName) {

        File tempFile = new File("output.txt");
        File inputFile = new File(fileName);
        try (
                FileReader fileReader = new FileReader(inputFile);
                BufferedReader br = new BufferedReader(fileReader);
                FileWriter tempFileWriter = new FileWriter(tempFile);
                BufferedWriter tempBufferedWriter = new BufferedWriter(tempFileWriter);
                PrintWriter out = new PrintWriter(tempBufferedWriter)){

            String line;

            while ((line = br.readLine()) != null) {
                String[] fields = line.split(",");
                if (!(fields[0].equalsIgnoreCase(movieName)  && fields[1].equalsIgnoreCase(directorName))) {
                    out.println(line);
                }
            }

            out.flush();

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println(e);
        }

        try {

            Files.delete(Paths.get(fileName));

            Files.move(Paths.get("output.txt"), Paths.get(fileName));
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println(e);
        }

        if (DVDsdata.isEmpty() == true){
            btnDelete.setDisable(true);
        }

    }

    private void removeFromCustomerFile(String fileName, String firstName, String lastName) {

        File tempFile = new File("output.txt");
        File inputFile = new File(fileName);
        try (
                FileReader fileReader = new FileReader(inputFile);
                BufferedReader br = new BufferedReader(fileReader);
                FileWriter tempFileWriter = new FileWriter(tempFile);
                BufferedWriter tempBufferedWriter = new BufferedWriter(tempFileWriter);
                PrintWriter out = new PrintWriter(tempBufferedWriter)){

            String line;

            while ((line = br.readLine()) != null) {
                String[] fields = line.split(",");
                if (!(fields[0].equalsIgnoreCase(firstName)  && fields[1].equalsIgnoreCase(lastName))) {
                    out.println(line);
                }
            }

            out.flush();

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println(e);
        }

        try {

            Files.delete(Paths.get(fileName));

            Files.move(Paths.get("output.txt"), Paths.get(fileName));
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println(e);
        }

        if (CustomerData.isEmpty() == true){
            btnRemove.setDisable(true);
        }

    }



    public void updateDVD() {
        ObservableList<DVD> currentTableData = DVDDisplay.getItems();
        int currentDVDID = Integer.parseInt(fieldIDCopy.getText());
        for (DVD dvd : currentTableData) {
            if(dvd.getIdNum() == currentDVDID){
                DVD selectedItem = DVDDisplay.getSelectionModel().getSelectedItem();
                if (selectedItem == null)
                    return;

                dvd.setMovieName(fieldMovieName.getText());
                dvd.setDirectorName(fieldDirector.getText());
                dvd.setIdNum(Integer.parseInt(fieldIDCopy.getText()));
                dvd.setAvailableYN(choiceboxAvailable.getValue().toString());

                DVDDisplay.setItems(currentTableData);
                DVDDisplay.refresh();

            }
        }
    }

    public void selectDVD(){
        fieldIDCopy.clear();
        fieldDirector.clear();
        fieldMovieName.clear();
        choiceboxAvailable.getSelectionModel().select(-1);
        DVD selectedItem = DVDDisplay.getSelectionModel().getSelectedItem();

        if (selectedItem == null)
            return;

        fieldMovieName.setText(selectedItem.getMovieName());
        fieldDirector.setText(selectedItem.getDirectorName());
        fieldIDCopy.setText(String.valueOf(selectedItem.getIdNum()));
        choiceboxAvailable.setValue(selectedItem.getAvailableYN());

        btnSubmit.setDisable(false);
        btnDelete.setDisable(false);
    }

    public void selectCustomer(){
        fieldCopyID.clear();
        fieldLastName.clear();
        fieldFirstName.clear();
        fieldMovieRented.clear();
        returnDatePicker.setValue(null);
        Customer selectedItem = CustomerDisplay.getSelectionModel().getSelectedItem();

        if (selectedItem == null)
            return;

        fieldFirstName.setText(selectedItem.getFirstName());
        fieldLastName.setText(selectedItem.getLastName());
        fieldCopyID.setText(String.valueOf(selectedItem.getIdNumCust()));
        fieldMovieRented.setText(selectedItem.getRentedMovie());
        LocalDate d = selectedItem.getReturnDate();
        returnDatePicker.setValue(d);

        btnRegister.setDisable(false);
        btnRemove.setDisable(false);
    }


    public void createNewDVD(ActionEvent actionEvent) throws IOException {
        if (validateDVDData()) {
            String movieName = fieldMovieName.getText();
            String directorName = fieldDirector.getText();
            String idNum = fieldIDCopy.getText();
            String availableYN = choiceboxAvailable.getValue().toString();

            if (checkDVDExists(Integer.valueOf(idNum))) {
                return;
            }

            DVDsdata.add(new DVD(movieName, directorName, Integer.valueOf(idNum), availableYN));
            addToDVD();

            fieldIDCopy.clear();
            fieldDirector.clear();
            fieldMovieName.clear();
            choiceboxAvailable.getSelectionModel().clearSelection();
            lblMessage.setVisible(false);

            btnSubmit.setDisable(false);
            btnDelete.setDisable(true);
        }
    }

    public void createNewCustomer(ActionEvent actionEvent) throws IOException {
        if (validateCustomerData()) {
            String firstName = fieldFirstName.getText();
            String lastName = fieldLastName.getText();
            String idNumCust = fieldCopyID.getText();
            String rentedMovie = fieldMovieRented.getText();
            LocalDate returnDate = returnDatePicker.getValue();
            if (checkCustomerExists(Integer.valueOf(idNumCust))) {
                return;
            }

            CustomerData.add(new Customer(firstName, lastName, Integer.valueOf(idNumCust), rentedMovie, returnDate));
            addToCustomer();

            fieldCopyID.clear();
            fieldLastName.clear();
            fieldFirstName.clear();
            fieldMovieRented.clear();
            lblMessage1.setVisible(false);
            returnDatePicker.getEditor().clear();

            btnRegister.setDisable(false);
            btnRemove.setDisable(true);
        }
    }


    private void loadDVD(String fileName) {

        FileReader fileReader = null;
        try {
            fileReader = new FileReader(fileName);
            BufferedReader br = new BufferedReader(fileReader);
            String line;

            while ((line = br.readLine()) != null) {
                DVD dvd = parseDVD(line);
                DVDsdata.add(dvd);

            }
            br.close();
            DVDDisplay.setItems(DVDsdata);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println(e);
        }
    }

    public void loadCustomer(String fileName) {

        FileReader fileReader = null;
        try {
            fileReader = new FileReader(fileName);
            BufferedReader br = new BufferedReader(fileReader);
            String line;

            while ((line = br.readLine()) != null) {
                Customer customer = parseCustomer(line);
                CustomerData.add(customer);

            }
            br.close();
            CustomerDisplay.setItems(CustomerData);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println(e);
        }
    }

    private boolean validateDVDData() {

        String movieName = fieldMovieName.getText();
        if (movieName.isBlank()) {
            lblMessage.setText("Please enter a movie name.");
            lblMessage.setVisible(true);
            return false;
        }

        String directorName = fieldDirector.getText();
        if (directorName.isBlank()) {
            lblMessage.setText("Please enter the director's name.");
            lblMessage.setVisible(true);
            return false;
        }

        String idNum = fieldIDCopy.getText();
        if (idNum.isBlank()) {
            lblMessage.setText("Please enter the DVD's id. Max 10 digits.");
            lblMessage.setVisible(true);
            return false;
        }

        if (choiceboxAvailable.getValue() == null) {
            lblMessage.setText("Please enter the DVD's availability.");
            lblMessage.setVisible(true);
            return false;
        }

        return true;
    }

    private boolean validateCustomerData() {

        String movieName = fieldFirstName.getText();
        if (movieName.isBlank()) {
            lblMessage1.setText("Please enter the customer's first name.");
            lblMessage1.setVisible(true);
            return false;
        }

        String directorName = fieldLastName.getText();
        if (directorName.isBlank()) {
            lblMessage1.setText("Please enter the customer's last name.");
            lblMessage1.setVisible(true);
            return false;
        }

        String rentedMovie = fieldMovieRented.getText();
        if (rentedMovie.isBlank()) {
            lblMessage1.setText("Please enter the movie the customer rented.");
            lblMessage1.setVisible(true);
            return false;
        }

        String idNumCust = fieldCopyID.getText();
        if (idNumCust.isBlank()) {
            lblMessage1.setText("Please enter the DVD's id. Max 10 digits");
            lblMessage1.setVisible(true);
            return false;
        }

        LocalDate returnDate = returnDatePicker.getValue();
        if (returnDate.compareTo(now) < 0) {
            //If the birthday is in the past, the code displays a message and doesn't proceed
            lblMessage1.setText("Please enter a valid return date.");
            lblMessage1.setVisible(true);
            return false;
        }

        return true;
    }



    private void writeToDVDFile(String fileName, String line) {
        try(FileWriter friendFileWrite = new FileWriter(fileName, true);
            BufferedWriter friendBufferedWriter = new BufferedWriter(friendFileWrite);
            PrintWriter out = new PrintWriter(friendBufferedWriter)) {
            out.println(line);
        }
        catch (IOException e) {
            System.err.println(e);
        }
    }

    private void writeToCustomerFile(String fileName, String line) {
        try(FileWriter friendFileWrite = new FileWriter(fileName, true);
            BufferedWriter friendBufferedWriter = new BufferedWriter(friendFileWrite);
            PrintWriter out = new PrintWriter(friendBufferedWriter)) {
            out.println(line);
        }
        catch (IOException e) {
            System.err.println(e);
        }
    }

    private void addToDVD() throws IOException{
        String dvdLine = buildDVDLine();
        writeToDVDFile("DVD_Catalogue.txt", dvdLine);
    }

    private void addToCustomer() throws IOException{
        String customerLine = buildCustomerLine();
        writeToCustomerFile("Customer_List.txt", customerLine);
    }

    private String buildDVDLine() {
        String movieName = fieldMovieName.getText();
        String directorName = fieldDirector.getText();
        String idNum = fieldIDCopy.getText();
        String availableYN = choiceboxAvailable.getValue().toString();

        return movieName + "," + directorName + "," + idNum + "," + availableYN;
    }

    private String buildCustomerLine() {
        String firstName = fieldFirstName.getText();
        String lastName = fieldLastName.getText();
        String idNumCust = fieldCopyID.getText();
        String rentedMovie = fieldMovieRented.getText();
        String returnDate = returnDatePicker.getValue().toString();

        return firstName + "," + lastName + "," + idNumCust + "," + rentedMovie + "," + returnDate;
    }
    private static DVD parseDVD(String line){
        String directorName = "";
        String movieName = "";
        String idNum = "";
        String availableYN = "";


        String[] fields = line.split(",");

        movieName = fields[0];
        directorName = fields[1];
        idNum = fields[2];
        availableYN = fields[3];


        return new DVD(movieName, directorName, Integer.valueOf(idNum), availableYN);
    }

    private static Customer parseCustomer(String line){
        String lastName = "";
        String firstName = "";
        String idNumCust = "";
        String rentedMovie = "";
        LocalDate returnDate = null;


        String[] fields = line.split(",");

        firstName = fields[0];
        lastName = fields[1];
        idNumCust = fields[2];
        rentedMovie = fields[3];
        returnDate = LocalDate.parse(fields[4], DateTimeFormatter.ofPattern("yyyy-MM-dd"));


        return new Customer(firstName, lastName, Integer.valueOf(idNumCust), rentedMovie, returnDate);
    }

    private boolean checkDVDExists(int idNum) {
        for(int i = 0; i < DVDsdata.size(); i++) {
            DVD friend = DVDsdata.get(i);
            if (friend.getIdNum() == (idNum)) {
                return true;
            }
        }

        return false;
    }

    private boolean checkCustomerExists(int idNumCust) {
        for(int i = 0; i < CustomerData.size(); i++) {
            Customer customer = CustomerData.get(i);
            if (customer.getIdNumCust() == (idNumCust)) {
                return true;
            }
        }

        return false;
    }

}